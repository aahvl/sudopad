.build/obj_sudopad_default/protocol/usb_device_state.o: \
 tmk_core/protocol/usb_device_state.c keyboards/sudopad/config.h \
 .build/obj_sudopad_default/src/info_config.h platforms/chibios/config.h \
 tmk_core/protocol/usb_device_state.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
tmk_core/protocol/usb_device_state.h:
