generated-files: $(wildcard /k/sudopad/info.json)

generated-files: $(wildcard /k/sudopad/keyboard.json)

generated-files: $(wildcard /k/sudopad/rules.mk)

generated-files: $(wildcard /k/sudopad/post_rules.mk)

generated-files: $(wildcard /k/sudopad/config.h)

generated-files: $(wildcard /k/sudopad/post_config.h)

generated-files: $(wildcard /c/Users/tux/qmk_firmware/keyboards/sudopad/keymaps/default/keymap.json)

generated-files: $(wildcard /c/Users/tux/qmk_firmware/keyboards/sudopad/keymaps/default/info.json)

generated-files: $(wildcard /c/Users/tux/qmk_firmware/keyboards/sudopad/keymaps/default/keyboard.json)

generated-files: $(wildcard /c/Users/tux/qmk_firmware/keyboards/sudopad/keymaps/default/rules.mk)

generated-files: $(wildcard /c/Users/tux/qmk_firmware/keyboards/sudopad/keymaps/default/post_rules.mk)

generated-files: $(wildcard /c/Users/tux/qmk_firmware/keyboards/sudopad/keymaps/default/config.h)

generated-files: $(wildcard /c/Users/tux/qmk_firmware/keyboards/sudopad/keymaps/default/post_config.h)

generated-files: $(wildcard /u/default/info.json)

generated-files: $(wildcard /u/default/keyboard.json)

generated-files: $(wildcard /u/default/rules.mk)

generated-files: $(wildcard /u/default/post_rules.mk)

generated-files: $(wildcard /u/default/config.h)

generated-files: $(wildcard /u/default/post_config.h)

