.build/obj_sudopad_default/wear_leveling.o: \
 quantum/wear_leveling/wear_leveling.c keyboards/sudopad/config.h \
 .build/obj_sudopad_default/src/info_config.h platforms/chibios/config.h \
 lib/fnv/fnv.h lib/fnv/longlong.h quantum/wear_leveling/wear_leveling.h \
 quantum/wear_leveling/wear_leveling_drivers.h \
 platforms/chibios/drivers/wear_leveling/wear_leveling_rp2040_flash_config.h \
 lib/pico-sdk/src/rp2_common/hardware_flash/include/hardware/flash.h \
 lib/pico-sdk/src/common/pico_base/include/pico.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/assert.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h \
 lib/pico-sdk/src/common/pico_base/include/pico/config.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h \
 lib/pico-sdk/src/boards/include/boards/pico.h \
 lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/error.h \
 quantum/wear_leveling/wear_leveling_internal.h \
 quantum/compiler_support.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
lib/fnv/fnv.h:
lib/fnv/longlong.h:
quantum/wear_leveling/wear_leveling.h:
quantum/wear_leveling/wear_leveling_drivers.h:
platforms/chibios/drivers/wear_leveling/wear_leveling_rp2040_flash_config.h:
lib/pico-sdk/src/rp2_common/hardware_flash/include/hardware/flash.h:
lib/pico-sdk/src/common/pico_base/include/pico.h:
lib/pico-sdk/src/common/pico_base/include/pico/types.h:
lib/pico-sdk/src/common/pico_base/include/pico/assert.h:
lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h:
lib/pico-sdk/src/common/pico_base/include/pico/config.h:
lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h:
lib/pico-sdk/src/boards/include/boards/pico.h:
lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h:
lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h:
lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h:
lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h:
lib/pico-sdk/src/common/pico_base/include/pico/types.h:
lib/pico-sdk/src/common/pico_base/include/pico/error.h:
quantum/wear_leveling/wear_leveling_internal.h:
quantum/compiler_support.h:
