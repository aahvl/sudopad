.build/obj_sudopad_default/printf.o: lib/printf/src/printf/printf.c \
 keyboards/sudopad/config.h .build/obj_sudopad_default/src/info_config.h \
 platforms/chibios/config.h lib/printf/src/printf/printf.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
lib/printf/src/printf/printf.h:
