.build/obj_sudopad_default/./lib/pico-sdk/src/rp2_common/hardware_claim/claim.o: \
 lib/pico-sdk/src/rp2_common/hardware_claim/claim.c \
 keyboards/sudopad/config.h .build/obj_sudopad_default/src/info_config.h \
 platforms/chibios/config.h \
 lib/pico-sdk/src/rp2_common/hardware_claim/include/hardware/claim.h \
 lib/pico-sdk/src/common/pico_base/include/pico.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/assert.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h \
 lib/pico-sdk/src/common/pico_base/include/pico/config.h \
 lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h \
 lib/pico-sdk/src/boards/include/boards/pico.h \
 lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h \
 lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h \
 lib/pico-sdk/src/common/pico_base/include/pico/types.h \
 lib/pico-sdk/src/common/pico_base/include/pico/error.h \
 lib/pico-sdk/src/rp2_common/hardware_sync/include/hardware/sync.h \
 lib/pico-sdk/src/rp2_common/hardware_base/include/hardware/address_mapped.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
lib/pico-sdk/src/rp2_common/hardware_claim/include/hardware/claim.h:
lib/pico-sdk/src/common/pico_base/include/pico.h:
lib/pico-sdk/src/common/pico_base/include/pico/types.h:
lib/pico-sdk/src/common/pico_base/include/pico/assert.h:
lib/chibios//os/various/pico_bindings/dumb/include/pico/version.h:
lib/pico-sdk/src/common/pico_base/include/pico/config.h:
lib/chibios//os/various/pico_bindings/dumb/include/pico/config_autogen.h:
lib/pico-sdk/src/boards/include/boards/pico.h:
lib/pico-sdk/src/rp2_common/pico_platform/include/pico/platform.h:
lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/platform_defs.h:
lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/addressmap.h:
lib/pico-sdk/src/rp2040/hardware_regs/include/hardware/regs/sio.h:
lib/pico-sdk/src/common/pico_base/include/pico/types.h:
lib/pico-sdk/src/common/pico_base/include/pico/error.h:
lib/pico-sdk/src/rp2_common/hardware_sync/include/hardware/sync.h:
lib/pico-sdk/src/rp2_common/hardware_base/include/hardware/address_mapped.h:
