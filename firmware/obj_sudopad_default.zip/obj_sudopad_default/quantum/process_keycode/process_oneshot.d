.build/obj_sudopad_default/quantum/process_keycode/process_oneshot.o: \
 quantum/process_keycode/process_oneshot.c keyboards/sudopad/config.h \
 .build/obj_sudopad_default/src/info_config.h platforms/chibios/config.h \
 quantum/process_keycode/process_oneshot.h quantum/action.h \
 platforms/progmem.h quantum/keyboard.h platforms/timer.h \
 platforms/chibios/_timer.h quantum/keycode.h quantum/keycodes.h \
 quantum/modifiers.h quantum/action_code.h quantum/action_util.h \
 quantum/compiler_support.h tmk_core/protocol/report.h quantum/util.h \
 quantum/bits.h quantum/bitwise.h platforms/chibios/_util.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
quantum/process_keycode/process_oneshot.h:
quantum/action.h:
platforms/progmem.h:
quantum/keyboard.h:
platforms/timer.h:
platforms/chibios/_timer.h:
quantum/keycode.h:
quantum/keycodes.h:
quantum/modifiers.h:
quantum/action_code.h:
quantum/action_util.h:
quantum/compiler_support.h:
tmk_core/protocol/report.h:
quantum/util.h:
quantum/bits.h:
quantum/bitwise.h:
platforms/chibios/_util.h:
