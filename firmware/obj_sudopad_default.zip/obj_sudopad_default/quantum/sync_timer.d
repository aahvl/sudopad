.build/obj_sudopad_default/quantum/sync_timer.o: quantum/sync_timer.c \
 keyboards/sudopad/config.h .build/obj_sudopad_default/src/info_config.h \
 platforms/chibios/config.h quantum/sync_timer.h platforms/timer.h \
 platforms/chibios/_timer.h quantum/keyboard.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
quantum/sync_timer.h:
platforms/timer.h:
platforms/chibios/_timer.h:
quantum/keyboard.h:
