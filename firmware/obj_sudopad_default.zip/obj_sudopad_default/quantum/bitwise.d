.build/obj_sudopad_default/quantum/bitwise.o: quantum/bitwise.c \
 keyboards/sudopad/config.h .build/obj_sudopad_default/src/info_config.h \
 platforms/chibios/config.h quantum/util.h quantum/bits.h \
 quantum/bitwise.h platforms/chibios/_util.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
quantum/util.h:
quantum/bits.h:
quantum/bitwise.h:
platforms/chibios/_util.h:
