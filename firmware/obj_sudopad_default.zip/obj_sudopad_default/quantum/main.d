.build/obj_sudopad_default/quantum/main.o: quantum/main.c \
 keyboards/sudopad/config.h .build/obj_sudopad_default/src/info_config.h \
 platforms/chibios/config.h quantum/keyboard.h platforms/timer.h \
 platforms/chibios/_timer.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
quantum/keyboard.h:
platforms/timer.h:
platforms/chibios/_timer.h:
