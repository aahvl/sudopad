.build/obj_sudopad_default/quantum/logging/debug.o: \
 quantum/logging/debug.c keyboards/sudopad/config.h \
 .build/obj_sudopad_default/src/info_config.h platforms/chibios/config.h \
 quantum/logging/debug.h quantum/logging/print.h quantum/util.h \
 quantum/bits.h quantum/bitwise.h platforms/chibios/_util.h \
 quantum/logging/sendchar.h platforms/progmem.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
quantum/logging/debug.h:
quantum/logging/print.h:
quantum/util.h:
quantum/bits.h:
quantum/bitwise.h:
platforms/chibios/_util.h:
quantum/logging/sendchar.h:
platforms/progmem.h:
