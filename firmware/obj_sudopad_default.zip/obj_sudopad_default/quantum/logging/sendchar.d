.build/obj_sudopad_default/quantum/logging/sendchar.o: \
 quantum/logging/sendchar.c keyboards/sudopad/config.h \
 .build/obj_sudopad_default/src/info_config.h platforms/chibios/config.h \
 quantum/logging/sendchar.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
quantum/logging/sendchar.h:
