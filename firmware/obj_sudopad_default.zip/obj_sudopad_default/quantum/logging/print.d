.build/obj_sudopad_default/quantum/logging/print.o: \
 quantum/logging/print.c keyboards/sudopad/config.h \
 .build/obj_sudopad_default/src/info_config.h platforms/chibios/config.h \
 quantum/logging/sendchar.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
quantum/logging/sendchar.h:
