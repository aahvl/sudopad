.build/obj_sudopad_default/platforms/chibios/syscall-fallbacks.o: \
 platforms/chibios/syscall-fallbacks.c keyboards/sudopad/config.h \
 .build/obj_sudopad_default/src/info_config.h platforms/chibios/config.h \
 platforms/chibios/errno.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
platforms/chibios/errno.h:
