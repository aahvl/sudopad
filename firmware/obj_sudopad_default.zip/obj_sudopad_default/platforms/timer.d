.build/obj_sudopad_default/platforms/timer.o: platforms/timer.c \
 keyboards/sudopad/config.h .build/obj_sudopad_default/src/info_config.h \
 platforms/chibios/config.h platforms/timer.h platforms/chibios/_timer.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
platforms/timer.h:
platforms/chibios/_timer.h:
