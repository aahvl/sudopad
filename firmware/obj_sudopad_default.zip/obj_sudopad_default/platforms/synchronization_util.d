.build/obj_sudopad_default/platforms/synchronization_util.o: \
 platforms/synchronization_util.c keyboards/sudopad/config.h \
 .build/obj_sudopad_default/src/info_config.h platforms/chibios/config.h \
 platforms/synchronization_util.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
platforms/synchronization_util.h:
