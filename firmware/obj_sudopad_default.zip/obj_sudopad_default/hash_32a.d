.build/obj_sudopad_default/hash_32a.o: lib/fnv/hash_32a.c \
 keyboards/sudopad/config.h .build/obj_sudopad_default/src/info_config.h \
 platforms/chibios/config.h lib/fnv/fnv.h lib/fnv/longlong.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
lib/fnv/fnv.h:
lib/fnv/longlong.h:
