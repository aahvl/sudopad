.build/obj_sudopad_default/hash_64a.o: lib/fnv/hash_64a.c \
 keyboards/sudopad/config.h .build/obj_sudopad_default/src/info_config.h \
 platforms/chibios/config.h lib/fnv/fnv.h lib/fnv/longlong.h
keyboards/sudopad/config.h:
.build/obj_sudopad_default/src/info_config.h:
platforms/chibios/config.h:
lib/fnv/fnv.h:
lib/fnv/longlong.h:
